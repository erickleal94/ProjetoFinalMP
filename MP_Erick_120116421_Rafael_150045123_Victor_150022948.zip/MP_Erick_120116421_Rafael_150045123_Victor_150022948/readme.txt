Para compilar o programa entre no diretorio "src" e digite o comando make.
Será criado um executável de nome "grafo".
O programa lê um arquivo texto com o nome "teste.txt" e cria um arquivo de nome "saida.txt".
Para alterar as tarefas lidas pelo programa, é preciso alterar o arquivo "teste.txt".
